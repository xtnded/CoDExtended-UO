#include "server.hpp"

SV_Trace_t SV_Trace = (SV_Trace_t)0x809A051;