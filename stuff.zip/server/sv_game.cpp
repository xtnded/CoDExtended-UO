#include "server.hpp"

SV_SendServerCommand_t SV_SendServerCommand = (SV_SendServerCommand_t)0x808E19A; // 1.5 0x808D443