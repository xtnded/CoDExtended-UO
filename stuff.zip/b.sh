cd /home/ext/
./build.sh
cp ./bin/codextended.so /home/cod/
cd /home/cod/
